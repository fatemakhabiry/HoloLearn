class ApiConfig {
  // UPDATE THIS WITH YOUR NGROK URL OR LOCAL IP
  static const String baseUrl =
      //fatma
      // "https://unflinchingly-effortful-deacon.ngrok-free.dev/api/v1";
      //Ahmed
      "https://unpointed-lynne-paradingly.ngrok-free.dev/api/v1";

  // ===== Authentication Endpoints =====
  static const String loginEndpoint = '/auth/login';

  // ===== User Endpoints =====
  static const String userProfileEndpoint = '/users/me';
  static const String updateProfileEndpoint = '/users/me';

  // ===== Teacher Endpoints =====
  static const String teacherProfileEndpoint = '/teachers/profile';
  static const String avatarStatusEndpoint = '/teachers/profile-status';
  static const String teacherUploadPhotoEndpoint = '/teachers/upload-photo';
  static const String teacherUploadVoiceEndpoint = '/teachers/upload-voice';
  static const String teacherVerifyPhotoEndpoint = '/teachers/verify-photo';

  // ===== Password Reset / OTP Endpoints =====
  static const String forgotPasswordEndpoint =
      '/password_reset/forgot-password';
  static const String verifyOtpEndpoint = '/password_reset/verify-otp';
  static const String resetPasswordEndpoint = '/password_reset/reset-password';
  static const String changePasswordEndpoint =
      '/password_reset/change-password';
  static const String resendOtpEndpoint = '/password_reset/resend-otp';

  // ===== Schedule Endpoints =====
  static const String reservedSlotsEndpoint =
      '/schedules/my-scheduled-lectures';
  static const String availabilitySlotsEndpoint = '/schedules/available-slots';

  //===== Lecture endpoints =====
  static const String lecturesEndpoint = '/lecture/';
  //prepared lecture endpoints
  static const String createLectureDraftEndpoint = '/lecture/create-draft';
  static const String startPreparedEndpoint =
      '/session/start-prepared/{lecture_id}';
  //Generated lecture endpoints
  static const String uploadGeneratedFileEndpoint = "/session/upload-resource";
  static const String startGeneratedSessionEndpoint = '/session/start';
  static const String getSessionStatusEndpoint = '/session/{session_id}/status';
  static const String getSessionStreamEndpoint = '/session/{session_id}/stream';
  static const String approveSessionEndpoint = '/session/{session_id}/approve';
  static const String rejectWithFeedbackSessionEndpoint =
      '/session/{session_id}/reject';
  // static const String getLectureContentEndpoint =
  //     '/session/{session_id}/content';
  static const String getLecturePdfEndpoint =
      '/session/{lecture_id}/lecture-pdf';
  static const String getLectureGeneratedResourceEndpoint =
      "/session/{lecture_id}/content/{content_type}/download";

  static const String publishLectureEndpoint =
      '/lecture/{lecture_id}/confirm-and-publish';
  static const String lectureHistoryendpoint = '/lecture/all-my-lectures';

  static const String cancleLectureEndpoint = '/schedules/{schedule_id}/cancel';
  static const String deleteLectureEndpoint = '/lecture/{lecture_id}';
  static const String updateLectureEndpoint =
      '/lecture/schedule/{schedule_id}/edit';
  static const String getLectureDetailsEndpoint =
      '/lecture/schedule/{schedule_id}/edit-details';
  static const String getFeedbackSuggestionsEndpoint =
      '/session/{session_id}/feedback-suggestions';

  // ===== Student Endpoints =====
  static const String courseListEndpoint = '/courses/';
  static const String studentLectureEndpoint = '/student/upcoming-lectures';
  static const String getStudentLectureContentEndpoint =
      "/session/lecture/{lecture_id}/content/{content_type}/download";
  static const String lectureTranscriptEndpoint =
      '/lecture/{lecture_id}/transcript';

  // ===== Q&A Endpoints =======
  /// Body: multipart — text (String) OR voice_file (audio)
  static const String qaAskEndpoint = '/qa/{lecture_id}/ask';
  static const String qaHistoryEndpoint = "/qa/{lecture_id}/history";
  static const String qaHistoryPdfEndpoint ="/qa/{lecture_id}/export-pdf"; 
  static const String qaIndexStatusEndpoint = '/qa/{lecture_id}/status';
  static const String qaAudioEndpoint = '/qa/audio/{message_id}';
  static const String qaClearSessionEndpoint = '/qa/session/{session_id}';

  // ===== Research Agent Endpoints =======
  static const String researchAgentEndpoint = '/research';

  // ===== Token Settings =====
  static const Duration tokenExpiry = Duration(minutes: 30);

  // ===== API Timeouts =====
  static const Duration connectionTimeout = Duration(minutes: 30);
  static const Duration receiveTimeout = Duration(seconds: 30);

  // ===== Helper Methods =====

  // Build full URL
  static String getUrl(String endpoint) => baseUrl + endpoint;
}
