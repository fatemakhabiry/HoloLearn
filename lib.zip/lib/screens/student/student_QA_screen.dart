import 'dart:async';
import 'dart:io';

import 'package:just_audio/just_audio.dart';
import 'package:flutter/material.dart';
import 'package:path_provider/path_provider.dart';
import 'package:provider/provider.dart';
import 'package:record/record.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../constants/constants.dart';
import '../../models/qa_models.dart';
import '../../models/schedule_models.dart';
import '../../providers/app_state_provider.dart';
import '../../services/qa_service.dart';
import '../../widgets/widgets.dart';

// ─── Internal UI model ────────────────────────────────────────────────────────

enum MessageSender { you, hologramAvatar }

enum MessageType { text, voice }

class ChatMessage {
  final String text;
  final MessageSender sender;
  final DateTime timestamp;
  final int? messageId;
  final MessageType type;
  final String? voicePath;
  final String? audioUrl; // TTS audio URL for AI answer messages

  ChatMessage({
    required this.text,
    required this.sender,
    DateTime? timestamp,
    this.messageId,
    this.type = MessageType.text,
    this.voicePath,
    this.audioUrl,
  }) : timestamp = timestamp ?? DateTime.now();

  factory ChatMessage.fromQAMessage(QAMessage msg, {String? audioUrl}) {
    return ChatMessage(
      text: msg.content,
      sender: msg.role == QAMessageRole.assistant
          ? MessageSender.hologramAvatar
          : MessageSender.you,
      timestamp: msg.createdAt,
      messageId: msg.messageId,
      audioUrl: audioUrl,
    );
  }

  factory ChatMessage.voice({
    required MessageSender sender,
    required String voicePath,
  }) {
    return ChatMessage(
      text: '',
      sender: sender,
      type: MessageType.voice,
      voicePath: voicePath,
    );
  }
}

// ─── Screen ───────────────────────────────────────────────────────────────────

class StudentQAScreen extends StatefulWidget {
  final ScheduleSlot session;

  const StudentQAScreen({super.key, required this.session});

  @override
  State<StudentQAScreen> createState() => _StudentQAScreenState();
}

class _StudentQAScreenState extends State<StudentQAScreen> {
  final TextEditingController _messageController = TextEditingController();
  final ScrollController _scrollController = ScrollController();

  bool isLoading = true;
  bool _isSending = false;
  bool _isInQueue = false;
  int? _queuePosition;
  int? _sessionId;

  bool _isIndexed = false;
  String _indexStatusLabel = 'Checking…';
  bool _isWaitingForAnswer =
      false; // shows typing bubble while RAG is processing

  final List<ChatMessage> _messages = [];

  int get _lectureId => widget.session.lectureId ?? 0;

  // ─── Lifecycle ─────────────────────────────────────────────────────────

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  @override
  void dispose() {
    _messageController.dispose();
    _scrollController.dispose();
    super.dispose();
  }

  // ─── Data loading ──────────────────────────────────────────────────────

  Future<void> _loadData() async {
    setState(() {
      isLoading = true;
      _isSending = false;
      _isIndexed = false;
    });
    try {
      final appState = Provider.of<AppStateProvider>(context, listen: false);

      final status = await QAService.getIndexStatus(
        appState: appState,
        lectureId: _lectureId,
      );

      if (!mounted) return;

      _isIndexed = status.isIndexed && status.status == QAIndexStatus.ready;
      _indexStatusLabel = _statusLabel(status.status);

      if (_isIndexed) {
        await _loadHistory(appState);
      }
    } catch (e) {
      if (!mounted) return;
      _indexStatusLabel = 'Status unavailable';
      CustomErrorHandler.show(
        context,
        message: e.toString().replaceFirst('Exception: ', ''),
        type: ErrorType.fail,
      );
    } finally {
      if (mounted) setState(() => isLoading = false);
    }
  }

  Future<void> _loadHistory(AppStateProvider appState) async {
    try {
      final history = await QAService.getHistory(
        appState: appState,
        lectureId: _lectureId,
      );
      if (!mounted) return;

      // Build a map of answerId → filePath from all saved local voice keys.
      // Storage format: key = "voice_path_local_<hash>", value = "<answerId>|<filePath>"
      final prefs = await SharedPreferences.getInstance();
      final allKeys = prefs.getKeys();
      final Map<int, String> answerIdToVoicePath = {};
      for (final key in allKeys) {
        if (!key.startsWith('voice_path_local_')) continue;
        final raw = prefs.getString(key);
        if (raw == null) continue;
        final parts = raw.split('|');
        if (parts.length < 2) continue;
        final answerId = int.tryParse(parts[0]);
        final filePath = parts
            .sublist(1)
            .join('|'); // rejoin in case path has |
        if (answerId != null && File(filePath).existsSync()) {
          answerIdToVoicePath[answerId] = filePath;
        }
      }

      final messages = history.messages.map((msg) {
        // Derive audioUrl for assistant messages that have an audio path
        String? audioUrl;
        if (msg.role == QAMessageRole.assistant &&
            msg.audioOutputPath != null &&
            msg.audioOutputPath!.isNotEmpty) {
          audioUrl = '/qa/audio/${msg.messageId}';
        }
        return ChatMessage.fromQAMessage(msg, audioUrl: audioUrl);
      }).toList();

      // Second pass: for each assistant message whose id is in answerIdToVoicePath,
      // find the preceding user message and upgrade it to a voice bubble.
      final resolved = <ChatMessage>[];
      for (int i = 0; i < messages.length; i++) {
        final msg = messages[i];
        if (msg.sender == MessageSender.hologramAvatar &&
            msg.messageId != null &&
            answerIdToVoicePath.containsKey(msg.messageId)) {
          // The message before this is the user voice question — upgrade it
          if (resolved.isNotEmpty &&
              resolved.last.sender == MessageSender.you &&
              resolved.last.type == MessageType.text &&
              resolved.last.text.isEmpty) {
            // Already a placeholder — replace
            resolved[resolved.length - 1] = ChatMessage(
              text: '',
              sender: MessageSender.you,
              timestamp: resolved.last.timestamp,
              messageId: resolved.last.messageId,
              type: MessageType.voice,
              voicePath: answerIdToVoicePath[msg.messageId],
            );
          } else if (resolved.isNotEmpty &&
              resolved.last.sender == MessageSender.you) {
            // Regular text user message before — upgrade to voice
            final prev = resolved.last;
            resolved[resolved.length - 1] = ChatMessage(
              text: '',
              sender: MessageSender.you,
              timestamp: prev.timestamp,
              messageId: prev.messageId,
              type: MessageType.voice,
              voicePath: answerIdToVoicePath[msg.messageId],
            );
          }
        }
        resolved.add(msg);
      }

      // Remove orphaned user messages: any user message that has no following
      // assistant reply means the RAG response was never saved — drop it.
      final clean = <ChatMessage>[];
      for (int i = 0; i < resolved.length; i++) {
        final msg = resolved[i];
        if (msg.sender == MessageSender.you) {
          final hasReply =
              i + 1 < resolved.length &&
              resolved[i + 1].sender == MessageSender.hologramAvatar;
          if (!hasReply) continue; // skip orphan
        }
        clean.add(msg);
      }

      setState(() {
        _sessionId = history.sessionId;
        _messages
          ..clear()
          ..addAll(clean);
      });
      _scrollToBottom();
    } catch (_) {
      // History is optional — silently ignore; user can still type
    }
  }

  String _statusLabel(QAIndexStatus s) {
    switch (s) {
      case QAIndexStatus.ready:
        return 'Ready';
      case QAIndexStatus.ingesting:
        return 'Preparing lecture content…';
      case QAIndexStatus.pending:
        return 'Pending indexing…';
      case QAIndexStatus.failed:
        return 'Indexing failed. Contact your teacher.';
    }
  }

  // ─── Actions ───────────────────────────────────────────────────────────

  Future<void> _sendMessage() async {
    final text = _messageController.text.trim();
    if (text.isEmpty || _isSending) return;

    final optimisticQuestion = ChatMessage(
      text: text,
      sender: MessageSender.you,
    );

    setState(() {
      _isSending = true;
      _isWaitingForAnswer = true;
      _messages.add(optimisticQuestion);
      _messageController.clear();
    });
    _scrollToBottom();

    final appState = Provider.of<AppStateProvider>(context, listen: false);
    try {
      final response = await QAService.askQuestion(
        appState: appState,
        lectureId: _lectureId,
        text: text,
      );
      if (!mounted) return;
      setState(() {
        _isWaitingForAnswer = false;
        // Replace the optimistic bubble with the real one (carries messageId)
        _messages.remove(optimisticQuestion);
        _messages.add(
          ChatMessage(
            text: optimisticQuestion.text,
            sender: MessageSender.you,
            timestamp: optimisticQuestion.timestamp,
            messageId: response.question.messageId != 0
                ? response.question.messageId
                : null,
          ),
        );
        _messages.add(
          ChatMessage.fromQAMessage(
            response.answer,
            audioUrl: response.audioUrl,
          ),
        );
        _sessionId ??= response.answer.sessionId;
      });
      _scrollToBottom();
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _isWaitingForAnswer = false;
        _messages.remove(optimisticQuestion);
      });
      CustomErrorHandler.show(
        context,
        message: e.toString().replaceFirst('Exception: ', ''),
        type: ErrorType.fail,
      );
    } finally {
      if (mounted) setState(() => _isSending = false);
    }
  }

  Future<void> _sendVoiceMessage(File audioFile) async {
    if (_isSending) return;

    // Generate a stable local key from the file path so we can restore
    // this voice bubble after the app restarts. We cannot rely on the
    // backend question messageId because QAAskResponse.question.messageId
    // is always 0 (placeholder — the backend only returns the answer id).
    final localKey = 'voice_path_local_${audioFile.path.hashCode}';

    // Show voice bubble optimistically so user sees it immediately
    final optimisticMsg = ChatMessage.voice(
      sender: MessageSender.you,
      voicePath: audioFile.path,
    );

    setState(() {
      _isSending = true;
      _isWaitingForAnswer = true;
      _messages.add(optimisticMsg);
    });
    _scrollToBottom();

    final appState = Provider.of<AppStateProvider>(context, listen: false);
    try {
      final response = await QAService.askQuestion(
        appState: appState,
        lectureId: _lectureId,
        voiceFile: audioFile,
      );
      if (!mounted) return;

      // Persist: value = "answerId|filePath" so _loadHistory can match the pair.
      final answerId = response.answer.messageId;
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString(localKey, '$answerId|${audioFile.path}');

      setState(() {
        _isWaitingForAnswer = false;
        _messages.remove(optimisticMsg);
        _messages.add(
          ChatMessage(
            text: '',
            sender: MessageSender.you,
            type: MessageType.voice,
            voicePath: audioFile.path,
            messageId: answerId, // use answerId so _clearSession can clean up
          ),
        );
        _messages.add(
          ChatMessage.fromQAMessage(
            response.answer,
            audioUrl: response.audioUrl,
          ),
        );
        _sessionId ??= response.answer.sessionId;
      });
      _scrollToBottom();
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _isWaitingForAnswer = false;
        _messages.remove(optimisticMsg);
      });
      CustomErrorHandler.show(
        context,
        message: e.toString().replaceFirst('Exception: ', ''),
        type: ErrorType.fail,
      );
    } finally {
      if (mounted) setState(() => _isSending = false);
    }
  }

  void _raiseHand() {
    setState(() {
      if (_isInQueue) {
        _isInQueue = false;
        _queuePosition = null;
      } else {
        _isInQueue = true;
        _queuePosition = 1;
      }
    });
  }

  void _clearSession() {
    if (_sessionId == null) return;

    CustomConfirmationDialog.show(
      context,
      title: 'Clear Chat',
      message: 'This will delete all messages in this session. Are you sure?',
      confirmButtonText: 'Clear',
      cancelButtonText: 'Cancel',
      onConfirm: () async {
        CustomConfirmationDialog.dismiss(context);
        setState(() => isLoading = true);
        final appState = Provider.of<AppStateProvider>(context, listen: false);
        try {
          await QAService.clearSession(
            appState: appState,
            sessionId: _sessionId!,
          );
          if (!mounted) return;
          // Remove all saved voice paths for this session
          final prefs = await SharedPreferences.getInstance();
          final allKeys = prefs.getKeys().toList();
          for (final msg in _messages) {
            if (msg.messageId != null) {
              // Clean old-style keys (legacy)
              await prefs.remove('voice_path_${msg.messageId}');
            }
          }
          // Clean new-style local keys whose stored answerId matches a msg in this session
          final sessionAnswerIds = _messages
              .where((m) => m.messageId != null)
              .map((m) => m.messageId!)
              .toSet();
          for (final key in allKeys) {
            if (!key.startsWith('voice_path_local_')) continue;
            final raw = prefs.getString(key);
            if (raw == null) continue;
            final answerId = int.tryParse(raw.split('|').first);
            if (answerId != null && sessionAnswerIds.contains(answerId)) {
              await prefs.remove(key);
            }
          }
          setState(() {
            _messages.clear();
            _sessionId = null;
          });
          CustomErrorHandler.show(
            context,
            message: 'Chat cleared.',
            type: ErrorType.success,
          );
        } catch (e) {
          if (!mounted) return;
          CustomErrorHandler.show(
            context,
            message: e.toString().replaceFirst('Exception: ', ''),
            type: ErrorType.fail,
          );
        } finally {
          if (mounted) setState(() => isLoading = false);
        }
      },
    );
  }

  void _scrollToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scrollController.hasClients) {
        _scrollController.animateTo(
          _scrollController.position.maxScrollExtent,
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeOut,
        );
      }
    });
  }

  // ─── Build ──────────────────────────────────────────────────────────────

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: CustomAppBar(
        title: 'Q&A Chat',
        actions: _sessionId != null
            ? [
                Padding(
                  padding: const EdgeInsets.only(right: AppStyles.spacingM),
                  child: IconButton(
                    tooltip: 'Clear chat',
                    icon: const Icon(Icons.delete_outline),
                    onPressed: _clearSession,
                  ),
                ),
              ]
            : null,
      ),
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      body: LoadingOverlay(
        isLoading: isLoading,
        child: !isLoading && !_isIndexed
            ? _NotReadyState(label: _indexStatusLabel, onRetry: _loadData)
            : Column(
                children: [
                  _TeacherStrip(session: widget.session),

                  if (_isInQueue && _queuePosition != null)
                    _QueueBanner(position: _queuePosition!),

                  Expanded(
                    child: RefreshIndicator(
                      onRefresh: _loadData,
                      child: _messages.isEmpty && !_isWaitingForAnswer
                          ? _EmptyChat(teacherName: widget.session.teacherName)
                          : ListView.builder(
                              controller: _scrollController,
                              physics: const AlwaysScrollableScrollPhysics(),
                              padding: const EdgeInsets.symmetric(
                                horizontal: AppStyles.spacingM,
                                vertical: AppStyles.spacingM,
                              ),
                              itemCount:
                                  _messages.length +
                                  (_isWaitingForAnswer ? 1 : 0),
                              itemBuilder: (context, index) {
                                if (index == _messages.length &&
                                    _isWaitingForAnswer) {
                                  return const _TypingBubble();
                                }
                                return _MessageBubble(
                                  message: _messages[index],
                                );
                              },
                            ),
                    ),
                  ),

                  _BottomBar(
                    controller: _messageController,
                    isInQueue: _isInQueue,
                    isSending: _isSending,
                    onRaiseHand: _raiseHand,
                    onSend: _sendMessage,
                    onVoiceSend: _sendVoiceMessage,
                  ),
                ],
              ),
      ),
    );
  }
}

// ─── Teacher Strip ────────────────────────────────────────────────────────────

class _TeacherStrip extends StatelessWidget {
  final ScheduleSlot session;
  const _TeacherStrip({required this.session});

  String _initials(String name) {
    final parts = name.trim().split(' ');
    if (parts.length >= 2) return '${parts[0][0]}${parts[1][0]}'.toUpperCase();
    if (parts.isNotEmpty && parts[0].isNotEmpty) {
      return parts[0][0].toUpperCase();
    }
    return '?';
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(
        horizontal: AppStyles.spacingM,
        vertical: AppStyles.spacingS,
      ),
      color: isDark ? AppColors.darkBorder : AppColors.secondaryColor,
      child: Row(
        children: [
          CircleAvatar(
            radius: 18,
            backgroundColor: AppColors.primaryColor.withOpacity(0.35),
            child: Text(
              _initials(session.teacherName),
              style: AppStyles.bodyMedium.copyWith(
                color: AppColors.white,
                fontWeight: AppFonts.semiBold,
              ),
            ),
          ),
          const SizedBox(width: AppStyles.spacingS),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  session.teacherName,
                  style: AppStyles.bodyLarge.copyWith(
                    color: AppColors.white,
                    fontWeight: AppFonts.semiBold,
                  ),
                ),
                if (session.courseCode.isNotEmpty)
                  Text(
                    session.courseCode,
                    style: AppStyles.caption.copyWith(
                      color: AppColors.white.withOpacity(0.75),
                    ),
                  ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// ─── Not Ready State ──────────────────────────────────────────────────────────

class _NotReadyState extends StatelessWidget {
  final String label;
  final VoidCallback onRetry;
  const _NotReadyState({required this.label, required this.onRetry});

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      physics: const AlwaysScrollableScrollPhysics(),
      child: SizedBox(
        height: MediaQuery.of(context).size.height - 200,
        child: Center(
          child: Padding(
            padding: const EdgeInsets.all(AppStyles.spacingXL),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Icon(
                  Icons.hourglass_bottom_rounded,
                  size: 52,
                  color: AppColors.primaryColor,
                ),
                const SizedBox(height: AppStyles.spacingM),
                Text('Lecture not ready', style: AppStyles.h3.copyWith(color: context.textPrimary)),
                const SizedBox(height: AppStyles.spacingS),
                Text(
                  label,
                  style: AppStyles.bodyMedium.copyWith(
                    color: context.textSecondary),
                    textAlign: TextAlign.center,
                  
                ),
                const SizedBox(height: AppStyles.spacingL),
                CustomButton(text: 'Retry', onPressed: onRetry),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

// ─── Empty State ──────────────────────────────────────────────────────────────

class _EmptyChat extends StatelessWidget {
  final String teacherName;
  const _EmptyChat({required this.teacherName});

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return SingleChildScrollView(
      physics: const AlwaysScrollableScrollPhysics(),
      child: SizedBox(
        height: MediaQuery.of(context).size.height - 300,
        child: Center(
          child: Padding(
            padding: const EdgeInsets.all(AppStyles.spacingXL),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  width: 72,
                  height: 72,
                  decoration: BoxDecoration(
                    color: AppColors.primaryColor.withOpacity(0.1),
                    shape: BoxShape.circle,
                  ),
                  child: const Icon(
                    Icons.chat_bubble_outline_rounded,
                    color: AppColors.primaryColor,
                    size: 36,
                  ),
                ),
                const SizedBox(height: AppStyles.spacingM),
                Text(
                  'Ask your question',
                  style: AppStyles.h3.copyWith(
                    color: isDark ? AppColors.textLight : AppColors.textBlack,
                  ),
                ),
                const SizedBox(height: AppStyles.spacingS),
                Text(
                  'Type your question below or raise your hand to speak directly with $teacherName\'s hologram avatar.',
                  textAlign: TextAlign.center,
                  style: AppStyles.bodyMedium.copyWith(
                    color: isDark
                        ? AppColors.darkTextSecondary
                        : AppColors.textLight,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

// ─── Queue Banner ─────────────────────────────────────────────────────────────

class _QueueBanner extends StatelessWidget {
  final int position;
  const _QueueBanner({required this.position});

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(
        vertical: AppStyles.spacingS,
        horizontal: AppStyles.spacingM,
      ),
      color: isDark
          ? AppColors.darkBorder
          : AppColors.primaryColor.withOpacity(0.08),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const Icon(
            Icons.people_outline,
            size: 16,
            color: AppColors.primaryColor,
          ),
          const SizedBox(width: AppStyles.spacingXS),
          RichText(
            text: TextSpan(
              style: AppStyles.bodyMedium.copyWith(
                color: AppColors.primaryColor,
              ),
              children: [
                const TextSpan(text: 'YOUR QUESTION QUEUE POSITION: '),
                TextSpan(
                  text: '#$position',
                  style: const TextStyle(fontWeight: FontWeight.w900),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// ─── Message Bubble (router) ──────────────────────────────────────────────────

class _MessageBubble extends StatelessWidget {
  final ChatMessage message;
  const _MessageBubble({required this.message});

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final isYou = message.sender == MessageSender.you;

    return Padding(
      padding: const EdgeInsets.only(bottom: AppStyles.spacingM),
      child: Column(
        crossAxisAlignment: isYou
            ? CrossAxisAlignment.end
            : CrossAxisAlignment.start,
        children: [
          // Sender label
          Padding(
            padding: const EdgeInsets.only(
              bottom: AppStyles.spacingXS,
              left: AppStyles.spacingXS,
              right: AppStyles.spacingXS,
            ),
            child: Text(
              isYou ? 'YOU' : 'HOLOGRAM AVATAR',
              style: AppStyles.caption.copyWith(
                fontWeight: AppFonts.semiBold,
                letterSpacing: 0.5,
                color: isYou
                    ? AppColors.primaryColor
                    : (isDark
                          ? AppColors.darkTextSecondary
                          : AppColors.textLight),
              ),
            ),
          ),
          // Bubble
          Row(
            mainAxisAlignment: isYou
                ? MainAxisAlignment.end
                : MainAxisAlignment.start,
            children: [
              Flexible(
                child: message.type == MessageType.voice
                    ? _VoiceBubble(message: message, isYou: isYou)
                    : _TextBubble(
                        message: message,
                        isYou: isYou,
                        isDark: isDark,
                      ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

// ─── Text Bubble ──────────────────────────────────────────────────────────────

class _TextBubble extends StatefulWidget {
  final ChatMessage message;
  final bool isYou;
  final bool isDark;
  const _TextBubble({
    required this.message,
    required this.isYou,
    required this.isDark,
  });

  @override
  State<_TextBubble> createState() => _TextBubbleState();
}

class _TextBubbleState extends State<_TextBubble> {
  // TTS playback state
  AudioPlayer? _ttsPlayer;
  bool _ttsLoading = false;
  bool _ttsPlaying = false;
  StreamSubscription<PlayerState>? _ttsStateSub;

  @override
  void dispose() {
    _ttsStateSub?.cancel();
    _ttsPlayer?.dispose();
    super.dispose();
  }

  Future<void> _toggleTts() async {
    final appState = Provider.of<AppStateProvider>(context, listen: false);
    final messageId = widget.message.messageId;
    if (messageId == null) return;

    // If player loaded — toggle play / pause (resume from same position)
    if (_ttsPlayer != null) {
      try {
        if (_ttsPlaying) {
          await _ttsPlayer!.pause();
        } else {
          if (_ttsPlayer!.processingState == ProcessingState.completed) {
            await _ttsPlayer!.seek(Duration.zero);
          }
          await _ttsPlayer!.play();
        }
      } catch (e) {
        debugPrint('TTS play error: $e');
      }
      return;
    }

    // First tap — fetch bytes, write to temp file, load and play
    setState(() => _ttsLoading = true);
    try {
      final dir = await getTemporaryDirectory();
      final file = File('${dir.path}/tts_$messageId.wav');

      if (!file.existsSync()) {
        final bytes = await QAService.getAudioBytes(
          appState: appState,
          messageId: messageId,
        );
        await file.writeAsBytes(bytes);
      }

      if (!mounted) return;

      _ttsPlayer = AudioPlayer();
      await _ttsPlayer!.setLoopMode(LoopMode.off);
      await _ttsPlayer!.setFilePath(file.path);

      _ttsStateSub = _ttsPlayer!.playerStateStream.listen((state) {
        if (!mounted) return;
        if (state.processingState == ProcessingState.completed) {
          setState(() => _ttsPlaying = false);
        } else {
          setState(() => _ttsPlaying = state.playing);
        }
      });

      if (mounted)
        setState(() => _ttsLoading = false); // clear loading before play
      await _ttsPlayer!.play();
    } catch (e) {
      if (!mounted) return;
      CustomErrorHandler.show(
        context,
        message: 'Could not load audio.',
        type: ErrorType.fail,
      );
      if (mounted) setState(() => _ttsLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final isYou = widget.isYou;
    final isDark = widget.isDark;
    final hasTts =
        !isYou &&
        widget.message.messageId != null &&
        widget.message.audioUrl != null;

    final bubble = Container(
      padding: const EdgeInsets.symmetric(
        horizontal: AppStyles.spacingM,
        vertical: AppStyles.spacingS + 2,
      ),
      decoration: isYou
          ? BoxDecoration(
              gradient: const LinearGradient(
                colors: [AppColors.primaryColor, AppColors.secondaryColor],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: const BorderRadius.only(
                topLeft: Radius.circular(AppStyles.radiusM),
                topRight: Radius.circular(AppStyles.radiusM),
                bottomLeft: Radius.circular(AppStyles.radiusM),
                bottomRight: Radius.circular(4.0),
              ),
              boxShadow: [
                BoxShadow(
                  color: AppColors.primaryColor.withOpacity(0.3),
                  blurRadius: 8,
                  offset: const Offset(0, 3),
                ),
              ],
            )
          : BoxDecoration(
              color: isDark ? AppColors.darkCard : AppColors.white,
              borderRadius: const BorderRadius.only(
                topLeft: Radius.circular(AppStyles.radiusM),
                topRight: Radius.circular(AppStyles.radiusM),
                bottomRight: Radius.circular(AppStyles.radiusM),
                bottomLeft: Radius.circular(4.0),
              ),
              boxShadow: AppStyles.cardShadow,
            ),
      child: Text(
        widget.message.text,
        style: AppStyles.bodyMedium.copyWith(
          color: isYou
              ? AppColors.white
              : (isDark ? AppColors.textLight : AppColors.textBlack),
        ),
      ),
    );

    if (!hasTts) return bubble;

    // AI bubble with TTS icon below
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        bubble,
        const SizedBox(height: 4),
        GestureDetector(
          onTap: _ttsLoading ? null : _toggleTts,
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
            decoration: BoxDecoration(
              color: isDark
                  ? AppColors.darkCard
                  : AppColors.primaryColor.withOpacity(0.08),
              borderRadius: BorderRadius.circular(AppStyles.radiusPill),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                _ttsLoading
                    ? SizedBox(
                        width: 14,
                        height: 14,
                        child: CircularProgressIndicator(
                          strokeWidth: 1.5,
                          color: AppColors.primaryColor,
                        ),
                      )
                    : Icon(
                        _ttsPlaying
                            ? Icons.pause_rounded
                            : Icons.volume_up_rounded,
                        size: 14,
                        color: AppColors.primaryColor,
                      ),
                const SizedBox(width: 5),
                Text(
                  _ttsLoading ? 'Loading…' : (_ttsPlaying ? 'Pause' : 'Listen'),
                  style: AppStyles.caption.copyWith(
                    color: AppColors.primaryColor,
                    fontWeight: AppFonts.semiBold,
                  ),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }
}

// ─── Typing Bubble ────────────────────────────────────────────────────────────

class _TypingBubble extends StatefulWidget {
  const _TypingBubble();

  @override
  State<_TypingBubble> createState() => _TypingBubbleState();
}

class _TypingBubbleState extends State<_TypingBubble>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 900),
    )..repeat();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return Padding(
      padding: const EdgeInsets.only(bottom: AppStyles.spacingM),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.only(
              bottom: AppStyles.spacingXS,
              left: AppStyles.spacingXS,
            ),
            child: Text(
              'HOLOGRAM AVATAR',
              style: AppStyles.caption.copyWith(
                fontWeight: AppFonts.semiBold,
                letterSpacing: 0.5,
                color: isDark
                    ? AppColors.darkTextSecondary
                    : AppColors.textLight,
              ),
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
            decoration: BoxDecoration(
              color: isDark ? AppColors.darkCard : AppColors.white,
              borderRadius: const BorderRadius.only(
                topLeft: Radius.circular(AppStyles.radiusM),
                topRight: Radius.circular(AppStyles.radiusM),
                bottomRight: Radius.circular(AppStyles.radiusM),
                bottomLeft: Radius.circular(4.0),
              ),
              boxShadow: AppStyles.cardShadow,
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: List.generate(3, (i) {
                return AnimatedBuilder(
                  animation: _controller,
                  builder: (context, _) {
                    // Each dot offset by 0.33 so they animate in sequence
                    final delay = i * 0.33;
                    final t = ((_controller.value + delay) % 1.0);
                    // Bounce: 0→1→0 over the cycle
                    final scale = t < 0.5
                        ? 0.6 + (t / 0.5) * 0.6
                        : 1.2 - ((t - 0.5) / 0.5) * 0.6;
                    return Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 3),
                      child: Transform.scale(
                        scale: scale,
                        child: Container(
                          width: 8,
                          height: 8,
                          decoration: BoxDecoration(
                            color: AppColors.primaryColor.withOpacity(0.7),
                            shape: BoxShape.circle,
                          ),
                        ),
                      ),
                    );
                  },
                );
              }),
            ),
          ),
        ],
      ),
    );
  }
}

// ─── Voice Bubble ─────────────────────────────────────────────────────────────

class _VoiceBubble extends StatefulWidget {
  final ChatMessage message;
  final bool isYou;
  const _VoiceBubble({required this.message, required this.isYou});

  @override
  State<_VoiceBubble> createState() => _VoiceBubbleState();
}

class _VoiceBubbleState extends State<_VoiceBubble> {
  late final AudioPlayer _player;
  bool _isPlaying = false;
  Duration _position = Duration.zero;
  Duration _total = Duration.zero;
  bool _loaded = false;
  bool _completed = false; // prevents infinite seek loop on completion

  // Keep subscription references so we can cancel them on dispose
  StreamSubscription<PlayerState>? _stateSub;
  StreamSubscription<Duration>? _posSub;
  StreamSubscription<Duration?>? _durSub;

  @override
  void initState() {
    super.initState();
    _player = AudioPlayer();
    _initPlayer();
  }

  Future<void> _initPlayer() async {
    final path = widget.message.voicePath;
    if (path == null) return;
    // Guard: file must exist on disk before handing to just_audio
    if (!File(path).existsSync()) {
      debugPrint('Voice file not found on disk: $path');
      return;
    }
    try {
      await _player.setLoopMode(LoopMode.off);
      final duration = await _player.setFilePath(path);
      if (!mounted) return;
      setState(() {
        _total = duration ?? Duration.zero;
        _loaded = true;
      });
    } catch (e) {
      debugPrint('just_audio setFilePath error: $e');
      return;
    }

    _stateSub = _player.playerStateStream.listen((state) {
      if (!mounted) return;
      if (state.processingState == ProcessingState.completed) {
        // Do NOT seek here — seeking inside the listener causes infinite loop
        setState(() {
          _isPlaying = false;
          _completed = true;
          _position = Duration.zero;
        });
      } else {
        setState(() {
          _isPlaying = state.playing;
          _completed = false;
        });
      }
    });

    _posSub = _player.positionStream.listen((pos) {
      if (!mounted) return;
      if (!_completed) setState(() => _position = pos);
    });

    _durSub = _player.durationStream.listen((dur) {
      if (!mounted || dur == null) return;
      setState(() => _total = dur);
    });
  }

  @override
  void dispose() {
    _stateSub?.cancel();
    _posSub?.cancel();
    _durSub?.cancel();
    _player.dispose();
    super.dispose();
  }

  Future<void> _togglePlay() async {
    if (!_loaded) return;
    try {
      if (_isPlaying) {
        await _player.pause();
      } else {
        // Seek to start on replay — safe here because it is user-triggered
        if (_completed ||
            _player.processingState == ProcessingState.completed) {
          await _player.seek(Duration.zero);
          setState(() => _completed = false);
        }
        await _player.play();
      }
    } catch (e) {
      debugPrint('just_audio play error: $e');
    }
  }

  String _fmt(Duration d) {
    final m = d.inMinutes.remainder(60).toString();
    final s = d.inSeconds.remainder(60).toString().padLeft(2, '0');
    return '$m:$s';
  }

  @override
  Widget build(BuildContext context) {
    final isYou = widget.isYou;
    final isDark = Theme.of(context).brightness == Brightness.dark;

    final bgColor = isYou
        ? AppColors.primaryColor
        : (isDark ? AppColors.darkCard : AppColors.white);
    final fgColor = isYou
        ? AppColors.white
        : (isDark ? AppColors.textLight : AppColors.textBlack);
    final sliderActive = isYou ? AppColors.white : AppColors.primaryColor;
    final sliderInactive = isYou
        ? AppColors.white.withOpacity(0.35)
        : AppColors.gray.withOpacity(0.3);

    final progress = _total.inMilliseconds > 0
        ? (_position.inMilliseconds / _total.inMilliseconds).clamp(0.0, 1.0)
        : 0.0;

    return Container(
      width: 230,
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      decoration: BoxDecoration(
        color: bgColor,
        borderRadius: BorderRadius.only(
          topLeft: const Radius.circular(AppStyles.radiusM),
          topRight: const Radius.circular(AppStyles.radiusM),
          bottomLeft: Radius.circular(isYou ? AppStyles.radiusM : 4),
          bottomRight: Radius.circular(isYou ? 4 : AppStyles.radiusM),
        ),
        boxShadow: isYou
            ? [
                BoxShadow(
                  color: AppColors.primaryColor.withOpacity(0.3),
                  blurRadius: 8,
                  offset: const Offset(0, 3),
                ),
              ]
            : AppStyles.cardShadow,
      ),
      child: Row(
        children: [
          GestureDetector(
            onTap: _togglePlay,
            child: Container(
              width: 40,
              height: 40,
              decoration: BoxDecoration(
                color: fgColor.withOpacity(0.15),
                shape: BoxShape.circle,
              ),
              child: Icon(
                _isPlaying ? Icons.pause_rounded : Icons.play_arrow_rounded,
                color: fgColor,
                size: 24,
              ),
            ),
          ),
          const SizedBox(width: 8),
          Expanded(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SliderTheme(
                  data: SliderThemeData(
                    trackHeight: 3,
                    thumbShape: const RoundSliderThumbShape(
                      enabledThumbRadius: 5,
                    ),
                    overlayShape: SliderComponentShape.noOverlay,
                    activeTrackColor: sliderActive,
                    inactiveTrackColor: sliderInactive,
                    thumbColor: sliderActive,
                  ),
                  child: Slider(
                    value: progress,
                    onChanged: _loaded
                        ? (val) async {
                            await _player.seek(
                              Duration(
                                milliseconds: (val * _total.inMilliseconds)
                                    .toInt(),
                              ),
                            );
                          }
                        : null,
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(left: 4),
                  child: Text(
                    !_loaded
                        ? '...'
                        : (_isPlaying || _position > Duration.zero
                              ? _fmt(_position)
                              : _fmt(_total)),
                    style: AppStyles.caption.copyWith(
                      fontSize: 11,
                      color: fgColor.withOpacity(0.75),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// ─── Bottom Bar ───────────────────────────────────────────────────────────────

class _BottomBar extends StatelessWidget {
  final TextEditingController controller;
  final bool isInQueue;
  final bool isSending;
  final VoidCallback onRaiseHand;
  final Future<void> Function() onSend;
  final Future<void> Function(File) onVoiceSend;

  const _BottomBar({
    required this.controller,
    required this.isInQueue,
    required this.isSending,
    required this.onRaiseHand,
    required this.onSend,
    required this.onVoiceSend,
  });

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final surfaceColor = isDark ? AppColors.darkCard : AppColors.white;
    final borderColor = isDark
        ? AppColors.darkBorder
        : AppColors.gray.withOpacity(0.2);

    return Container(
      decoration: BoxDecoration(
        color: surfaceColor,
        border: Border(top: BorderSide(color: borderColor, width: 1)),
      ),
      child: SafeArea(
        top: false,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(
            AppStyles.spacingM,
            AppStyles.spacingM,
            AppStyles.spacingM,
            AppStyles.spacingS,
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              // Raise Hand button
              SizedBox(
                width: double.infinity,
                child: OutlinedButton.icon(
                  onPressed: onRaiseHand,
                  icon: Icon(
                    isInQueue ? Icons.back_hand : Icons.back_hand_outlined,
                    size: 18,
                    color: isInQueue ? AppColors.white : AppColors.primaryColor,
                  ),
                  label: Text(
                    isInQueue ? 'LEAVE QUEUE' : 'RAISE HAND FOR QUEUE',
                    style: AppStyles.button.copyWith(
                      color: isInQueue
                          ? AppColors.white
                          : AppColors.primaryColor,
                      letterSpacing: 0.5,
                    ),
                  ),
                  style: OutlinedButton.styleFrom(
                    backgroundColor: isInQueue
                        ? AppColors.primaryColor
                        : Colors.transparent,
                    side: const BorderSide(
                      color: AppColors.primaryColor,
                      width: 1.5,
                    ),
                    padding: const EdgeInsets.symmetric(
                      vertical: AppStyles.spacingM,
                    ),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(AppStyles.radiusPill),
                    ),
                  ),
                ),
              ),
              const SizedBox(height: AppStyles.spacingS),
              Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: controller,
                      onSubmitted: (_) => onSend(),
                      enabled: !isSending,
                      style: AppStyles.bodyMedium.copyWith(
                        color: isDark
                            ? AppColors.textLight
                            : AppColors.textBlack,
                      ),
                      decoration: InputDecoration(
                        hintText: 'Type your question...',
                        hintStyle: AppStyles.caption,
                        filled: true,
                        fillColor: isDark
                            ? AppColors.darkBackground
                            : AppColors.lightBackground,
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(
                            AppStyles.radiusPill,
                          ),
                          borderSide: BorderSide.none,
                        ),
                        enabledBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(
                            AppStyles.radiusPill,
                          ),
                          borderSide: BorderSide.none,
                        ),
                        focusedBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(
                            AppStyles.radiusPill,
                          ),
                          borderSide: const BorderSide(
                            color: AppColors.primaryColor,
                            width: 1.5,
                          ),
                        ),
                        contentPadding: const EdgeInsets.symmetric(
                          horizontal: AppStyles.spacingM,
                          vertical: AppStyles.spacingS + 2,
                        ),
                        suffixIcon: _MicButton(
                          onVoiceSend: onVoiceSend,
                          disabled: isSending,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: AppStyles.spacingS),
                  _SendButton(onPressed: onSend, isLoading: isSending),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ─── Mic Button ───────────────────────────────────────────────────────────────

class _MicButton extends StatefulWidget {
  final Future<void> Function(File) onVoiceSend;
  final bool disabled;

  const _MicButton({required this.onVoiceSend, this.disabled = false});

  @override
  State<_MicButton> createState() => _MicButtonState();
}

class _MicButtonState extends State<_MicButton> {
  final AudioRecorder _recorder = AudioRecorder();
  bool _isRecording = false;

  @override
  void dispose() {
    _recorder.dispose();
    super.dispose();
  }

  Future<void> _toggleRecording() async {
    if (widget.disabled) return;
    if (_isRecording) {
      await _stopAndSend();
    } else {
      await _startRecording();
    }
  }

  Future<void> _startRecording() async {
    final hasPermission = await _recorder.hasPermission();
    if (!hasPermission) {
      if (mounted) {
        CustomErrorHandler.show(
          context,
          message: 'Microphone permission denied.',
          type: ErrorType.fail,
        );
      }
      return;
    }

    // Save to external Downloads so the file persists and is user-accessible
    Directory? dir;
    if (Platform.isAndroid) {
      dir = Directory('/storage/emulated/0/Download/QAVoiceMessages');
    } else {
      dir = await getApplicationDocumentsDirectory();
    }
    if (!await dir.exists()) await dir.create(recursive: true);

    final path =
        '${dir.path}/qa_voice_${DateTime.now().millisecondsSinceEpoch}.wav';

    await _recorder.start(
      const RecordConfig(
        encoder: AudioEncoder.wav,
        bitRate: 128000,
        sampleRate: 44100,
      ),
      path: path,
    );

    if (mounted) setState(() => _isRecording = true);
  }

  Future<void> _stopAndSend() async {
    final path = await _recorder.stop();
    if (mounted) setState(() => _isRecording = false);

    if (path == null || path.isEmpty) return;
    final file = File(path);
    if (!await file.exists()) return;

    await widget.onVoiceSend(file);
  }

  @override
  Widget build(BuildContext context) {
    final color = widget.disabled
        ? AppColors.gray
        : (_isRecording ? AppColors.error : AppColors.primaryColor);

    return Padding(
      padding: const EdgeInsets.only(right: AppStyles.spacingXS),
      child: GestureDetector(
        onTap: _toggleRecording,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 200),
          width: 36,
          height: 36,
          decoration: BoxDecoration(
            color: color.withOpacity(0.12),
            shape: BoxShape.circle,
          ),
          child: Icon(
            _isRecording ? Icons.stop_rounded : Icons.mic_outlined,
            color: color,
            size: 20,
          ),
        ),
      ),
    );
  }
}

// ─── Send Button ──────────────────────────────────────────────────────────────

class _SendButton extends StatelessWidget {
  final Future<void> Function() onPressed;
  final bool isLoading;

  const _SendButton({required this.onPressed, this.isLoading = false});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: isLoading ? null : onPressed,
      child: Container(
        width: 48,
        height: 48,
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [
              isLoading ? AppColors.gray : AppColors.primaryColor,
              isLoading ? AppColors.gray : AppColors.secondaryColor,
            ],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          shape: BoxShape.circle,
          boxShadow: isLoading
              ? []
              : [
                  BoxShadow(
                    color: AppColors.primaryColor.withOpacity(0.35),
                    blurRadius: 10,
                    offset: const Offset(0, 4),
                  ),
                ],
        ),
        child: isLoading
            ? const Padding(
                padding: EdgeInsets.all(14),
                child: CircularProgressIndicator(
                  strokeWidth: 2,
                  color: AppColors.white,
                ),
              )
            : const Icon(Icons.send_rounded, color: AppColors.white, size: 22),
      ),
    );
  }
}
