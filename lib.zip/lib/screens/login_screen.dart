import 'dart:io';
import 'dart:async';
import 'package:http/http.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';

import '../providers/lecture_state_provider.dart';
import '../services/biometric_service.dart';
import '../state/processing_notifier.dart';
import '../widgets/widgets.dart';
import '../routes/app_routes.dart';
import '../constants/constants.dart';
import '../services/auth_service.dart';
import '../providers/app_state_provider.dart';
import '../utils/storage_helper.dart';

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();

  Map<String, dynamic>? data;
  String? email;
  String? password;
  String message = "";
  bool _obscureText = true;
  bool _showbanner = false;
  bool is_loading = false;
  String? error_message = null;
  bool _rememberMe = false; // NEW: Remember Me checkbox state

  @override
  void initState() {
    super.initState();
    _loadSavedEmail(); // NEW: Load saved email on init
  }

  @override
  void dispose() {
    _emailController.dispose();
    _passwordController.dispose();
    super.dispose();
  }

  // Load saved email (and password if rememberMe) from storage
  Future<void> _loadSavedEmail() async {
    final appState = Provider.of<AppStateProvider>(context, listen: false);
    await appState.init(); // Load from storage

    if (appState.email.isNotEmpty && mounted) {
      final savedPassword = appState.rememberMe
          ? await StorageHelper.getPassword()
          : null;

      setState(() {
        _emailController.text = appState.email;
        // _rememberMe = appState.rememberMe;
        if (savedPassword != null && savedPassword.isNotEmpty) {
          _passwordController.text = savedPassword;
        }
      });
    }
  }

  // Future<void> _handleLogin() async {
  //   setState(() {
  //     is_loading = true;
  //   });
  //   try {
  //     data = await AuthService.login(email: email!, password: password!);

  //     // Set app state
  //     final appState = Provider.of<AppStateProvider>(context, listen: false);
  //     await appState.setEmail(data!['user']['email']);
  //     await appState.setUserName(data!['user']['full_name']);
  //     await appState.setUserRole(data!['user']['role']);
  //     await appState.setAccessToken(data!['access_token']);
  //     await appState.setRememberMe(_rememberMe);

  //     // Save password securely so auto-login works on next app launch
  //     if (_rememberMe) {
  //       await StorageHelper.savePassword(password!);
  //     } else {
  //       // If user unchecked Remember Me, clear any previously saved password
  //       await StorageHelper.savePassword('');
  //     }

  //     if (mounted) {
  //       if (appState.userRole == 'teacher') {
  //         Navigator.pushReplacementNamed(context, AppRoutes.teacherDashboard);
  //       } else {
  //         Navigator.pushReplacementNamed(context, AppRoutes.studentDashboard);
  //       }
  //     }
  //   } on ClientException {
  //     error_message = 'Cannot connect to server. Check internet or URL.';
  //   } on SocketException {
  //     error_message = 'No internet connection.';
  //   } on TimeoutException {
  //     error_message = 'Request timed out.';
  //   } catch (e) {
  //     error_message = e.toString().replaceFirst('Exception: ', '');
  //   } finally {
  //     if (error_message != null) {
  //       CustomErrorHandler.show(
  //         context,
  //         message: error_message!,
  //         type: ErrorType.fail,
  //       );
  //       error_message = null;
  //     }
  //     if (mounted) {
  //       setState(() {
  //         is_loading = false;
  //       });
  //     }
  //   }
  // }
  Future<void> _handleLogin() async {
    setState(() {
      is_loading = true;
    });
    try {
      final data = await AuthService.login(email: email!, password: password!);

      final appState = Provider.of<AppStateProvider>(context, listen: false);
      await appState.setUserData(
        email: data['user']['email'],
        userName: data['user']['full_name'],
        role: data['user']['role'],
        accessToken: data['access_token'],
      );
      final sessionId = data['user']['latest_session_id'];

      if (sessionId != null) {
        await StorageHelper.saveOngoingSessionId(sessionId as int);
      }

      if (_rememberMe) {
        await StorageHelper.savePassword(password!);
        await StorageHelper.saveEmail(email!);
        await StorageHelper.saveRememberMe(true);

        // Silently enable biometrics if device supports it — no extra prompt
        final bioAvailable = await BiometricService.isAvailable();
        await StorageHelper.saveBiometricEnabled(bioAvailable);
      } else {
        await StorageHelper.savePassword('');
        await StorageHelper.saveBiometricEnabled(false);
      }

      if (mounted) {
        if (appState.userRole == 'teacher') {
          final lectureState = Provider.of<LectureStateProvider>(
            context,
            listen: false,
          );
          final processingNotifier = Provider.of<ProcessingNotifier>(
            context,
            listen: false,
          );

          // Restore lecture state (including ongoingSessionId) from storage
          await lectureState.init();

          // If a session was in progress when the app was killed, resume polling
          if (lectureState.hasOngoingSession) {
            try {
              await processingNotifier
                  .resumeIfNeeded(appState)
                  .timeout(const Duration(seconds: 3));
            } catch (_) {
              // If resuming fails (e.g. session expired), just continue to dashboard
            }
          }

          Navigator.pushReplacementNamed(context, AppRoutes.teacherDashboard);
        } else {
          Navigator.pushReplacementNamed(context, AppRoutes.studentDashboard);
        }
      }
    } on ClientException {
      error_message = 'Cannot connect to server. Check internet or URL.';
    } on SocketException {
      error_message = 'No internet connection.';
    } on TimeoutException {
      error_message = 'Request timed out.';
    } catch (e) {
      error_message = e.toString().replaceFirst('Exception: ', '');
    } finally {
      if (error_message != null) {
        CustomErrorHandler.show(
          context,
          message: error_message!,
          type: ErrorType.fail,
        );
        error_message = null;
      }
      if (mounted) {
        setState(() {
          is_loading = false;
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: _onWillPop,
      child: Scaffold(
        backgroundColor: Theme.of(context).scaffoldBackgroundColor,
        body: LoadingOverlay(
          isLoading: is_loading,
          child: Center(
            child: SingleChildScrollView(
              child: Padding(
                padding: const EdgeInsets.all(AppStyles.spacingL),
                child: Container(
                  constraints: const BoxConstraints(maxWidth: 400),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      // Logo Badge
                      Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: AppStyles.spacingM,
                          vertical: AppStyles.spacingS,
                        ),
                        decoration: BoxDecoration(
                          color: AppColors.primaryColor,
                          borderRadius: BorderRadius.circular(
                            AppStyles.radiusPill,
                          ),
                        ),
                        child: Text(
                          'HOLOGRAPHIC LEARNING',
                          style: AppStyles.caption.copyWith(
                            color: context.isDark
                                ? AppColors.darkBackground
                                : AppColors.white,
                            fontWeight: AppFonts.semiBold,
                            letterSpacing: 1.2,
                          ),
                        ),
                      ),
                      const SizedBox(height: AppStyles.spacingM),
                      // HoloLearn Title
                      Text(
                        'HoloLearn',
                        style: AppStyles.logo.copyWith(
                          color: context.textPrimary,
                        ),
                      ),

                      const SizedBox(height: AppStyles.spacingXS),
                      // Subtitle
                      Text(
                        'Next-generation virtual education',
                        style: AppStyles.bodyMedium.copyWith(
                          color: context.textSecondary,
                        ),
                      ),
                      const SizedBox(height: AppStyles.spacingXL),
                      // Login Form Card
                      Container(
                        padding: const EdgeInsets.all(AppStyles.spacingL),
                        decoration: BoxDecoration(
                          color: Theme.of(context).cardColor,
                          borderRadius: BorderRadius.circular(
                            AppStyles.radiusXL,
                          ),
                          boxShadow: AppStyles.cardShadow,
                        ),
                        child: Form(
                          key: _formKey,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              CustomTextFormField(
                                controller:
                                    _emailController, // NEW: Add controller
                                hintText: 'Enter your email',
                                label: "Email Address",
                                keyboardType: TextInputType.emailAddress,
                                validator: (value) {
                                  if (value == null || value.isEmpty) {
                                    return 'Email is required';
                                  }
                                  if (!value.contains('@')) {
                                    return 'Enter a valid email';
                                  }
                                  return null;
                                },
                                onSaved: (value) => email = value,
                              ),
                              const SizedBox(height: AppStyles.spacingL),
                              CustomTextFormField(
                                controller:
                                    _passwordController, // NEW: Add controller
                                suffixIcon: IconsButton(
                                  size: 24,
                                  iconColor: Colors.grey,
                                  backgroundColor: Colors.transparent,
                                  icon: _obscureText
                                      ? Icons.visibility_off
                                      : Icons.visibility,
                                  onPressed: () {
                                    setState(
                                      () => _obscureText = !_obscureText,
                                    );
                                  },
                                ),
                                hintText: 'Enter your password',
                                label: "Password",
                                obscureText: _obscureText,
                                validator: (value) {
                                  if (value == null || value.isEmpty) {
                                    return 'Password is required';
                                  }
                                  return null;
                                },
                                onSaved: (value) => password = value,
                              ),
                              const SizedBox(height: AppStyles.spacingM),

                              // NEW: Remember Me Checkbox Row
                              Row(
                                children: [
                                  Checkbox(
                                    value: _rememberMe,
                                    onChanged: (value) {
                                      setState(() {
                                        _rememberMe = value ?? false;
                                      });
                                    },
                                    activeColor: AppColors.primaryColor,
                                    materialTapTargetSize:
                                        MaterialTapTargetSize.shrinkWrap,
                                    visualDensity: VisualDensity.compact,
                                  ),
                                  Text(
                                    'Remember me',
                                    style: AppStyles.bodyMedium.copyWith(
                                      color: context.textPrimary,
                                    ),
                                  ),
                                  const Spacer(),
                                  // Forgot Password Link (moved to row)
                                  TextButton(
                                    onPressed: () {
                                      // Navigator.push(
                                      //   context,
                                      //   MaterialPageRoute(
                                      //     builder: (context) =>
                                      //         const ForgetPasswordPage(),
                                      //   ),
                                      // );
                                      Navigator.pushNamed(
                                        context,
                                        AppRoutes.forgetPassword,
                                      );
                                    },
                                    style: TextButton.styleFrom(
                                      padding: EdgeInsets.zero,
                                      minimumSize: Size.zero,
                                      tapTargetSize:
                                          MaterialTapTargetSize.shrinkWrap,
                                    ),
                                    child: Text(
                                      'Forgot Password?',
                                      style: AppStyles.link.copyWith(
                                        color: AppColors.primaryColor,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                              const SizedBox(height: AppStyles.spacingL),

                              // Login Button
                              CustomButton(
                                text: 'LOG IN',
                                fullWidth: true,
                                onPressed: () async {
                                  if (_formKey.currentState!.validate()) {
                                    _formKey.currentState!.save();
                                    _showbanner = false;
                                    await _handleLogin();
                                  } else {
                                    // Form is not valid
                                    setState(() {
                                      _showbanner = true;
                                      message =
                                          "Please fill all fields correctly!";
                                    });
                                  }
                                },
                              ),
                            ],
                          ),
                        ),
                      ),
                      if (_showbanner) ...[
                        const SizedBox(height: AppStyles.spacingL),
                        MessageDisplay(
                          isSuccess: false,
                          massegeBanner: "Error",
                          message: message,
                          onDismiss: () => setState(() => message = ''),
                        ),
                      ],
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Future<bool> _onWillPop() async {
    try {
      if (Platform.isAndroid || Platform.isIOS) {
        SystemNavigator.pop();
      } else {
        exit(0);
      }
    } catch (_) {
      SystemNavigator.pop();
    }

    return false;
  }
}
